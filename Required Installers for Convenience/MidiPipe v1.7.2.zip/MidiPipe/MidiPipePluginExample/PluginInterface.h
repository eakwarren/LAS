@import Cocoa;
@import CoreMIDI;

typedef void (*MidiPipePluginCallback)(void *tool, Byte *currentMessage, ByteCount messageSize, MIDITimeStamp time, BOOL isLast);

@protocol MidiPipePluginProtocol <NSCoding>

//	initializeClass: is called once when the plug-in is loaded. The plug-in's bundle is passed
//	as argument; the plug-in could discover its own bundle again, but since we have it available
//	anyway when this is called, this saves some time and space.
//	This method should do all global plug-in initialization, such as loading preferences; if
//	initialization fails, it should return NO, and the plug-in won't be called again.
+ (BOOL)initializeClass:(NSBundle*)theBundle;

	//	terminateClass is called once when the plug-in won't be used again. NSBundle-based plug-ins
	//	can't be unloaded at present, this capability may be added to Cocoa in the future.
+ (void)terminateClass;

	//	pluginsFor: is called whenever the calling application wants to instantiate a plug-in class.
	//	An object is passed in as argument; this object might be validated by the plug-in class to
	//	decide which sort of instances, or how many instances to return. The object reference may also
	//	be stored by the instances and thereafter be used as a bridge to the calling application.
	//	This method returns an enumerator of an array of plug-in instances. This enumerator, the array
	//	itself, and the plug-in instances are all autoreleased, so the calling application needs to retain
	//	whatever it wants to keep. If no instances were generated, this returns nil.
+ (NSEnumerator*)pluginsFor:(id)anObject;

- (NSString *)name;
- (int)group;
	//- (id)initWithCoder:(NSCoder *)coder;
	//- (void)encodeWithCoder:(NSCoder *)coder;
- (void)enable;
- (void)disable;
- (NSView *)view;
- (void)updateView:(BOOL)update;
- (void)initInterface;
- (void)handleMidiMessage:(Byte *)currentMessage ofSize:(ByteCount)messageSize timeStamp:(MIDITimeStamp)time isLast:(BOOL)isLast;
- (void)setCallback:(MidiPipePluginCallback)newCallback forTool:(void *)tool;
- (id)initWithCoder:(NSCoder *)coder;
- (void)encodeWithCoder:(NSCoder *)coder;
@end

