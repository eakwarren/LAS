require('./server/open-stage-control-server')
