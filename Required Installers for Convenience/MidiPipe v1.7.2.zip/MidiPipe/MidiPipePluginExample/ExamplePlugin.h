//
//  ExamplePlugIn.h
//  MidiPipePluginExample
//
//  Created by Nico Wald on 28.08.05.
//  Copyright 2005 SubtleSoft. All rights reserved.
//

#import "PluginInterface.h"
@import Cocoa;

//	This is the plug-in class interface. All methods of the plug-in protocol must be
//	implemented. Common methods and instance variables of the plug-in class cluster may
//	also be declared here. Usually the main class itself will never be instantiated.
//	IBOutlets and IBActions are more conveniently declared in the subclasses, unless they're
//	common to all subclasses. In the example, the IBOutlet to the view (and the method that
//	returns it) could have been moved to the main class by using the same outlet name
//	in both associated nib files.
@interface MidiPipePlugin : NSObject<MidiPipePluginProtocol>
{
   IBOutlet NSView        *view;
   MidiPipePluginCallback callback;
   void                   *tool;
   NSString	              *nibName;
   BOOL	                 enabled;
   BOOL	                 updateView;
   BOOL	                 panelMode;
}
- (id)initWithNibName:(NSString *)newNibName;
- (NSString *)name;
- (NSString *)nibName;
- (int)group;
- (void)enable;
- (void)disable;
- (NSView *)view;
- (void)updateView:(BOOL)update;
- (void)initInterface;
- (void)setCallback:(MidiPipePluginCallback)newCallback forTool:(void *)tool;
- (void)handleMidiMessage:(Byte *)currentMessage ofSize:(ByteCount)messageSize timeStamp:(MIDITimeStamp)time isLast:(BOOL)isLast;
@end

//	This is one of the concrete plug-in classes which may be instantiated;
@interface ExamplePlugin : MidiPipePlugin
{
   IBOutlet NSSlider         *slider_size;
   IBOutlet NSSlider         *slider_delay;
   IBOutlet NSSlider         *slider_count;
   IBOutlet NSLevelIndicator *level_bandwidth;
   NSTimer                   *timer;
   int                       dataSize;
   UInt64                   lastTime;
   NSLock                    *dataLock;
}
+ (ExamplePlugin*)pluginFor:(id)anObject;
- (IBAction)setValue:(id)sender;
- (void)update:(NSTimer *)aTimer;
- (void)addData:(id)messageSize;
@end
