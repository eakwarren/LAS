//
//  ExamplePlugin.m
//  MidiPipePluginExample
//
//  Created by Nico on 28.08.05.
//  Copyright 2005 SubtleSoft. All rights reserved.
//

#import "ExamplePlugin.h"
@import MachO;
@import CoreAudio;

//	The plug-in is most conveniently implemented as a class cluster. The pluginsFor: method
//	may examine its parameter object and decide to return as many instances of its several
//	concrete subclasses. The calling application doesn't (and shouldn't) care which actual
//	subclass instances it gets back, and just treats each one as a NSObject<PAPluginProtocol>.

//	Variables common to all plug-in instances and subclasses are declared as
//	static globals. Here we store a reference to the plug-in's bundle, which would be
//	convenient to access local resources like icons and help files. We also use the bundle
//	reference as an indicator to check whether the plug-in has already been initialized.
static NSBundle* pluginBundle = nil;

@implementation MidiPipePlugin

+ (void)initialize
{
   if(self == [MidiPipePlugin class])
   {
      [self setVersion:0];
   }
}

//	initializeClass: is called once when the plug-in is loaded. The plug-in's bundle is passed
//	as argument; the plug-in could discover its own bundle again, but since we have it available
//	anyway when this is called, this saves some time and space.
//	This method should do all global plug-in initialization, such as loading preferences; if
//	initialization fails, it should return NO, and the plug-in won't be called again.
+ (BOOL)initializeClass:(NSBundle*)theBundle 
{
   if (pluginBundle)
   {
      return NO;
   }
   pluginBundle = [theBundle retain];
   return YES;
}

//	terminateClass is called once when the plug-in won't be used again. NSBundle-based plug-ins
//	can't be unloaded at present, this capability may be added to Cocoa in the future.
//	Here we release the bundle's reference and zero out the pointer, just for form's sake.
+ (void)terminateClass 
{
   if (pluginBundle)
   {
      [pluginBundle release];
      pluginBundle = nil;
   }
}

//	pluginsFor: is called whenever the calling application wants to instantiate a plug-in class.
//	An object is passed in as parameter; this object might be validated by the plug-in class to
//	decide which sort of instances, or how many instances to return. The object reference may also
//	be stored by the instances and thereafter be used as a bridge to the calling application.
//	This method returns an enumerator of an array of plug-in instances. This enumerator, the array
//	itself, and the plug-in instances are all autoreleased, so the calling application needs to retain
//	whatever it wants to keep. If no instances were generated, this returns nil.
//	Here we just try to instantiate one of each subclass, repassing the parameter object to the
//	subclass' pluginFor: method; if this returns nil, the subclass doesn't want to handle that
//	particular object.
+ (NSEnumerator*)pluginsFor:(id)anObject
{
   ExamplePlugin* examplep;
   
   NSMutableArray* plugs = [[[NSMutableArray alloc] init] autorelease];
   if ((examplep = [ExamplePlugin pluginFor:anObject]))
   {
      [plugs addObject:examplep];
   }
   return [plugs count]?[plugs objectEnumerator]:nil;
}

//	initWithObject:name: is the designated initializer for the plug-in class cluster.
//	It stores the retained parameter references.
- (id)initWithNibName:(NSString *)newNibName
{
   self       = [super init];
   nibName    = [newNibName retain];
   callback   = NULL;
   tool       = NULL;
   enabled    = FALSE;
   panelMode  = NO;
   updateView = NO;
   return self;
}

//	dealloc for the plug-in class cluster, of course, releases the parameter references.
- (void)dealloc 
{
   [nibName release];
   [super dealloc];
}

- (NSString *)name
{
   return @"undefined name";
}

- (NSString *)nibName
{
   return nibName;
}

- (int)group
{
   return 3; // 1 Input, 2 Output, 3 Modifier
}

- (void)enable
{
   if(!enabled)
   {
      if(panelMode) [self updateView:YES];
      enabled = TRUE;
   }
}

- (void)disable
{
   if(enabled)
   {
      [self updateView:NO];
      enabled = FALSE;
   }
}

- (NSView*)view
{
   return view;
}

- (void)updateView:(BOOL)update
{
   updateView = update;
}

- (void)initInterface
{
}

- (void)handleMidiMessage:(Byte *)currentMessage ofSize:(ByteCount)messageSize timeStamp:(MIDITimeStamp)time isLast:(BOOL)isLast
{
   if(callback && tool)
   {
      callback(tool, currentMessage, messageSize, time, isLast);
   }
}

- (void)setCallback:(MidiPipePluginCallback)newCallback forTool:(void *)newTool;
{
   callback = newCallback;
   tool = newTool;
}

- (id)initWithCoder:(NSCoder *)coder
{
   NSInteger version = [coder versionForClassName:@"MidiPipePlugin"];
   
   switch(version)
   {
      case 0:
         callback = NULL;
         tool     = NULL;
         nibName  = [[coder decodeObjectForKey:@"nibName"]retain];
         [NSBundle loadNibNamed:nibName owner:self];
         break;
   }
   if (self && view)
   {
      return self;
   }
   return nil;
}

- (void) encodeWithCoder:(NSCoder *)coder
{
   [coder encodeObject:nibName forKey:@"nibName"];
}
@end

//	This is one of the concrete plug-in classes which may be instantiated;
@implementation ExamplePlugin
//	pluginFor: returns a single instance of the plug-in subclass, or nil if the parameter
//	object (or some external circumstance) is inappropriate.
+ (ExamplePlugin*)pluginFor:(id)anObject
{
   ExamplePlugin* instance = [[[ExamplePlugin alloc] initWithNibName:@"MidiPipePluginExample"] autorelease];
   if (instance && [NSBundle loadNibNamed:[instance nibName] owner:instance] && [instance view]) 
   {
      return instance;
   }
   return nil;
}

- (id)initWithNibName:(NSString *)newNibName
{
   self       = [super initWithNibName:newNibName];
   dataSize   = 0;
   lastTime   = 0;
   dataLock = [[NSLock alloc]init];
   return self;
}

- (NSString *)name
{
   return @"Bandwidth Test";
}

- (int)group
{
   return 3; // 1 Input, 2 Output, 3 Modifier
}

//	dealloc needs to release the top-level view, since the nib was loaded by the plug-in
- (void)dealloc 
{
   [view release];
   [dataLock release];
   [super dealloc];
}

- (void)initInterface
{
   [level_bandwidth setIntValue:0];
}

- (void)addData:(id)messageSize
{
   [dataLock lock];
   dataSize += [messageSize intValue];
   [dataLock unlock];
   [messageSize release];
}

- (void)handleMidiMessage:(Byte *)currentMessage ofSize:(ByteCount)messageSize timeStamp:(MIDITimeStamp)time isLast:(BOOL)isLast
{
   if(enabled)
   {
      UInt64 now = mach_absolute_time();
      UInt64 delay = (now > time)?0:time - now;
      double timeStamp = AudioConvertHostTimeToNanos(delay)/1e9;
      NSNumber *size = [[NSNumber alloc]initWithUnsignedLong:messageSize];
      
      [self performSelector:@selector(addData:) withObject:size afterDelay:timeStamp];
   }
   [super handleMidiMessage:currentMessage ofSize:messageSize timeStamp:time isLast:isLast];
}

- (IBAction)setValue:(id)sender
{
   switch([sender tag])
   {
      case 3: // button
      {
         int size = [slider_size intValue];
         int count = [slider_count intValue];
         int counter = 0;
         
         Byte buffer[size];
         
         memset(buffer, size, 0);
         buffer[0] = 0xF0;
         buffer[size-1] = 0xF7;
         
         UInt64 timeStamp = mach_absolute_time();
         UInt64 delay = AudioConvertNanosToHostTime([slider_delay intValue]*1e6);
         
         for(; counter < count; ++counter)
         {
            [self handleMidiMessage:buffer ofSize:size timeStamp:timeStamp isLast:!((counter + 1) < count)];
            timeStamp += delay;
         }
      }
   }
}

- (void)updateView:(BOOL)update
{
   if(update != updateView)
   {
      [super updateView:update];
      if(update)
      {
         dataSize = 0;
         lastTime = 0;
         timer = [[NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(update:) userInfo:nil repeats:YES]retain];
         [[NSRunLoop currentRunLoop] addTimer:timer forMode:@"NSEventTrackingRunLoopMode"];
      }
      else
      {
         [timer invalidate];
         [timer release];
      }
   }
}

- (void)update:(NSTimer *)aTimer
{
   const int maxBandwidth = 3225; // 31,5*1024/10 = 3225,6
   UInt64 now = mach_absolute_time();
   double elapsed = (double)(AudioConvertHostTimeToNanos(now - lastTime)/1.0e9);
   int maxData = round(maxBandwidth*elapsed);
   
   [dataLock lock];
   int value = (int)round((50.0*dataSize)/maxData);
   if(maxData >= dataSize)
   {
      dataSize = 0;
   }
   else
   {
      dataSize -= maxData;
   }
   [dataLock unlock];
   
   lastTime = now;
   
   [level_bandwidth setIntValue:value];
}

- (id)initWithCoder:(NSCoder *)coder
{
   NSInteger version = [coder versionForClassName:@"ExamplePlugin"];
   
   switch(version)
   {
      case 0:
      {
         if(self = [super initWithCoder:coder])
         {
            [slider_size setIntValue:[coder decodeIntForKey:@"slider_size"]];
            [slider_delay setIntValue:[coder decodeIntForKey:@"slider_delay"]];
            [slider_count setIntValue:[coder decodeIntForKey:@"slider_count"]];
            
            [slider_size performClick:nil];
            [slider_delay performClick:nil];
            [slider_count performClick:nil];
         }
         break;
      }
   }
   dataLock = [[NSLock alloc]init];
   return self;
}

- (void) encodeWithCoder:(NSCoder *)coder
{
   [super encodeWithCoder:coder];
   [coder encodeInt:[slider_size intValue] forKey:@"slider_size"];
   [coder encodeInt:[slider_delay intValue] forKey:@"slider_delay"];
   [coder encodeInt:[slider_count intValue] forKey:@"slider_count"];
}
@end
